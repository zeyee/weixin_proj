Page({
  onShareAppMessage:function()
  {
   return{title:"共享印"}
  },
})